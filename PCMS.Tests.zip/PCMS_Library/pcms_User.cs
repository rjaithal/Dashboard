﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PCMS_Library
{
    public class pcms_Website
    {
        public string WEBSITE_PK { get; set; }
        public int WEBSITE_ID { get; set; }
        public string WEBSITE_URL { get; set; }
        public string WEBSITE_SITEMAP_URL { get; set; }
        public bool SDK_VERIFIED { get; set; }
        public DateTime INSERTED_DATE { get; set; }
        public string UPDATED_BY { get; set; }
        public DateTime UPDATED_DATE { get; set; }
        public int TS_CNT { get; set; }
        public string INSERTED_BY { get; set; }
    }
}
