﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PCMS_Library
{
   public  class pcms_Content
    {
       public string CONTENT_PK { get; set; }
       public string CONTENT_NAME { get; set; }
       public int CONTENT_ID { get; set; }
       public string CONTENT_DESCRIPTION { get; set; }
       public string CONTENT_HTML { get; set; }
       public string CONTENT_FIELDS { get; set; }
       public string INSERTED_BY { get; set; }
       public DateTime INSERTED_DATE { get; set; }
       public string UPDATED_BY { get; set; }
       public DateTime  UPDATED_DATE { get; set; }
       public bool CONTENT_ISDELETED { get; set; }
       public int TS_CNT { get; set; }
    }
}
