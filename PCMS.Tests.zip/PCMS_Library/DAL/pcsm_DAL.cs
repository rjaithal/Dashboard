﻿using pcsm_Utilities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PCMS_Library.DAL
{
    public class pcsm_DAL
    {
        public string _connectionString = System.Configuration.ConfigurationManager.ConnectionStrings["PCMS_DbConnection"].ConnectionString;
        public pcms_Admin userCredential(pcms_Admin _admin)
        {
            try
            {
                pcms_Admin _adminCredential = new pcms_Admin();
                using (SqlConnection con = new SqlConnection(_connectionString))
                {
                    con.Open();
                    SqlCommand command = new SqlCommand(null, con);
                    command.CommandText = "select ADMIN_ID from pcms_admin where ADMIN_USERNAME=@username and ADMIN_PASSWORD=@Pwd";
                    SqlParameter userName = new SqlParameter("@username", SqlDbType.NVarChar, 16);
                    SqlParameter passWord = new SqlParameter("@Pwd", SqlDbType.NVarChar, 16);
                    userName.Value = _admin.ADMIN_USERNAME;
                    passWord.Value = _admin.ADMIN_PASSWORD;
                    command.Parameters.Add(userName);
                    command.Parameters.Add(passWord);
                    command.Prepare();
                    SqlDataReader dr = command.ExecuteReader();
                    string str = "";
                    while (dr.Read())
                    {
                        _adminCredential.ADMIN_ID = dr.IsDBNull(0) ? 0 : Convert.ToInt16(dr[0]);
                    }
                    con.Close();
                    return _adminCredential;
                }
            }
            catch (Exception ex)
            {
                Utilities objUtilities = new Utilities();
                objUtilities.LogError(ex);
                return null;
            }
        }
        public List<pcms_Campaign> ListCampaign()
        {
            try
            {
                List<pcms_Campaign> _campaign = new List<pcms_Campaign>();
                using (SqlConnection con = new SqlConnection(_connectionString))
                {
                    con.Open();
                    SqlCommand command = new SqlCommand(null, con);
                    command.CommandText = "select PK_CAMPAIGN,CAMPAIGN_ID,CAMPAIGN_NAME,CAMPAIGN_START_DATE,CAMPAIGN_END_DATE,CAMPAIGN_STATUS  from pcms_campaign  order by CAMPAIGN_START_DATE desc ";
                    command.Prepare();
                    SqlDataReader dr = command.ExecuteReader();
                    string str = "";
                    while (dr.Read())
                    {
                        _campaign.Add(new pcms_Campaign
                        {
                            PK_CAMPAIGN = dr[0].ToString(),
                            CAMPAIGN_ID = dr[1].ToString(),
                            CAMPAIGN_NAME = dr[2].ToString(),
                            CAMPAIGN_START_DATE = Convert.ToDateTime(dr[3]),
                            CAMPAIGN_END_DATE = Convert.ToDateTime(dr[4]),
                            CAMPAIGN_STATUS = Convert.ToString(dr[5]),


                        });
                    }
                    con.Close();
                    return _campaign;
                }
            }
            catch (Exception ex)
            {
                Utilities objUtilities = new Utilities();
                objUtilities.LogError(ex);
                return null;
            }
        }
        public List<pcms_Design> getDesignTemplates()
        {
            try
            {
                List<pcms_Design> _Design = new List<pcms_Design>();
                using (SqlConnection con = new SqlConnection(_connectionString))
                {
                    con.Open();
                    SqlCommand command = new SqlCommand(null, con);
                    command.CommandText = "select DESIGN_ID,DESIGN_NAME from pcms_design where DESIGN_ISDELETED=0 order by INSERTED_DATE desc ";
                    command.Prepare();
                    SqlDataReader dr = command.ExecuteReader();
                    string str = "";
                    while (dr.Read())
                    {
                        _Design.Add(new pcms_Design
                        {
                            DESIGN_ID = Convert.ToInt16(dr[0].ToString()),
                            DESIGN_NAME = Cryptographys.Decrypt(dr[1].ToString()),
                        });
                    }
                    con.Close();
                    return _Design;
                }
            }
            catch (Exception ex)
            {
                Utilities objUtilities = new Utilities();
                objUtilities.LogError(ex);
                return null;
            }
        }
        public List<pcms_Content> getContentTemplates()
        {
            try
            {
                List<pcms_Content> _Content = new List<pcms_Content>();
                using (SqlConnection con = new SqlConnection(_connectionString))
                {
                    con.Open();
                    SqlCommand command = new SqlCommand(null, con);
                    command.CommandText = "select CONTENT_ID,CONTENT_NAME from pcms_content where CONTENT_ISDELETED=0 order by INSERTED_DATE desc ";
                    command.Prepare();
                    SqlDataReader dr = command.ExecuteReader();
                    string str = "";
                    while (dr.Read())
                    {
                        _Content.Add(new pcms_Content
                        {
                            CONTENT_ID = Convert.ToInt16(dr[0].ToString()),
                            CONTENT_NAME = Cryptographys.Decrypt(dr[1].ToString()),
                        });
                    }
                    con.Close();
                    return _Content;
                }
            }
            catch (Exception ex)
            {
                Utilities objUtilities = new Utilities();
                objUtilities.LogError(ex);
                return null;
            }
        }
        public List<pcms_Popup> getPopupTemplates()
        {
            try
            {
                List<pcms_Popup> _Popup = new List<pcms_Popup>();
                using (SqlConnection con = new SqlConnection(_connectionString))
                {
                    con.Open();
                    SqlCommand command = new SqlCommand(null, con);
                    command.CommandText = "select POPUP_ID,POPUP_NAME from pcms_popup where POPUP_ISDELETED=0 order by INSERTED_DATE desc ";
                    command.Prepare();
                    SqlDataReader dr = command.ExecuteReader();
                    string str = "";
                    while (dr.Read())
                    {
                        _Popup.Add(new pcms_Popup
                        {
                            POPUP_ID = Convert.ToInt16(dr[0].ToString()),
                            POPUP_NAME = Cryptographys.Decrypt(dr[1].ToString()),
                        });
                    }
                    con.Close();
                    return _Popup;
                }
            }
            catch (Exception ex)
            {
                Utilities objUtilities = new Utilities();
                objUtilities.LogError(ex);
                return null;
            }
        }
        public List<pcms_Rules> getListofRules()
        {
            try
            {
                List<pcms_Rules> _Rules = new List<pcms_Rules>();
                using (SqlConnection con = new SqlConnection(_connectionString))
                {
                    con.Open();
                    SqlCommand command = new SqlCommand(null, con);
                    command.CommandText = "select RULE_ID,RULE_NAME from pcms_rules where RULE_ISDELETED=0 order by INSERTED_DATE desc ";
                    command.Prepare();
                    SqlDataReader dr = command.ExecuteReader();
                    string str = "";
                    while (dr.Read())
                    {
                        _Rules.Add(new pcms_Rules
                        {
                            RULE_ID = Convert.ToInt16(dr[0].ToString()),
                            RULE_NAME = Cryptographys.Decrypt(dr[1].ToString()),
                        });
                    }
                    con.Close();
                    return _Rules;
                }
            }
            catch (Exception ex)
            {
                Utilities objUtilities = new Utilities();
                objUtilities.LogError(ex);
                return null;
            }
        }
        public string InsertCampaignData(pcms_Campaign _campaign)
        {
            string Msg = "";
            try
            {
                using (SqlConnection con = new SqlConnection(_connectionString))
                {
                    con.Open();
                    SqlCommand com = new SqlCommand(null, con);
                    com.CommandText = "select count(*) as count from pcms_campaign where CAMPAIGN_NAME=@CAMPAIGN_NAME";
                    SqlParameter campaignName = new SqlParameter("@CAMPAIGN_NAME", SqlDbType.VarChar, 50);
                    campaignName.Value = _campaign.CAMPAIGN_NAME;
                    com.Parameters.Add(campaignName);
                    com.Prepare();
                    SqlDataReader dr = com.ExecuteReader();
                    string str = "";
                    while (dr.Read())
                    {
                        if (Convert.ToInt16(dr[0]) > 0)
                        {
                            Msg = "Duplicate";
                        }
                        else
                        {
                            SqlCommand command = new SqlCommand(null, con);
                            command.CommandText = "insert into pcms_campaign(CAMPAIGN_NAME,CAMPAIGN_DESCRIPTION,CAMPAIGN_START_DATE,CAMPAIGN_END_DATE,CAMPAIGN_STATUS,CAMPAIGN_DESIGN_ID,CAMPAIGN_CONTENT_ID,CAMPAIGN_POPUP_STATUS,CAMPAIGN_POPUP_ID,CAMPAIGN_RULE_ID,CAMPAIGN_URL,CAMPAIGN_REDIRECT_URL,CAMPAIGN_CONTAINER_ID,INSERTED_BY,INSERTED_DATE,TS_CNT) values(@CAMPAIGN_NAME,@CAMPAIGN_DESCRIPTION,@CAMPAIGN_START_DATE,@CAMPAIGN_END_DATE,@CAMPAIGN_STATUS,@CAMPAIGN_DESIGN_ID,@CAMPAIGN_CONTENT_ID,@CAMPAIGN_POPUP_STATUS,@CAMPAIGN_POPUP_ID,@CAMPAIGN_RULE_ID,@CAMPAIGN_URL,@CAMPAIGN_REDIRECT_URL,@CAMPAIGN_CONTAINER_ID,@INSERTED_BY,@INSERTED_DATE,@TS_CNT)";
                            SqlParameter CAMPAIGN_NAME = new SqlParameter("@CAMPAIGN_NAME", SqlDbType.VarChar, 50);
                            SqlParameter CAMPAIGN_DESCRIPTION = new SqlParameter("@CAMPAIGN_DESCRIPTION", SqlDbType.NVarChar, 1000);
                            SqlParameter CAMPAIGN_START_DATE = new SqlParameter("@CAMPAIGN_START_DATE", SqlDbType.Date, -1);
                            SqlParameter CAMPAIGN_END_DATE = new SqlParameter("@CAMPAIGN_END_DATE", SqlDbType.Date, -1);
                            SqlParameter CAMPAIGN_STATUS = new SqlParameter("@CAMPAIGN_STATUS", SqlDbType.VarChar, 10);
                            SqlParameter CAMPAIGN_DESIGN_ID = new SqlParameter("@CAMPAIGN_DESIGN_ID", SqlDbType.Int, 16);
                            SqlParameter CAMPAIGN_CONTENT_ID = new SqlParameter("@CAMPAIGN_CONTENT_ID", SqlDbType.Int, 16);
                            SqlParameter CAMPAIGN_POPUP_STATUS = new SqlParameter("@CAMPAIGN_POPUP_STATUS", SqlDbType.VarChar, 8);
                            SqlParameter CAMPAIGN_POPUP_ID = new SqlParameter("@CAMPAIGN_POPUP_ID", SqlDbType.Int, 16);
                            SqlParameter CAMPAIGN_RULE_ID = new SqlParameter("@CAMPAIGN_RULE_ID", SqlDbType.Int, 16);
                            SqlParameter CAMPAIGN_URL = new SqlParameter("@CAMPAIGN_URL", SqlDbType.NVarChar, -1);
                            SqlParameter CAMPAIGN_REDIRECT_URL = new SqlParameter("@CAMPAIGN_REDIRECT_URL", SqlDbType.NVarChar, -1);
                            SqlParameter CAMPAIGN_CONTAINER_ID = new SqlParameter("@CAMPAIGN_CONTAINER_ID", SqlDbType.NVarChar, 16);
                            SqlParameter INSERTED_BY = new SqlParameter("@INSERTED_BY", SqlDbType.NVarChar, 16);
                            SqlParameter INSERTED_DATE = new SqlParameter("@INSERTED_DATE", SqlDbType.DateTime, -1);
                            SqlParameter TS_CNT = new SqlParameter("@TS_CNT", SqlDbType.Int, 16);
                            command.Parameters.Add(CAMPAIGN_NAME);
                            command.Parameters.Add(CAMPAIGN_DESCRIPTION);
                            command.Parameters.Add(CAMPAIGN_START_DATE);
                            command.Parameters.Add(CAMPAIGN_END_DATE);
                            command.Parameters.Add(CAMPAIGN_STATUS);
                            command.Parameters.Add(CAMPAIGN_DESIGN_ID);
                            command.Parameters.Add(CAMPAIGN_CONTENT_ID);
                            command.Parameters.Add(CAMPAIGN_POPUP_STATUS);
                            command.Parameters.Add(CAMPAIGN_POPUP_ID);
                            command.Parameters.Add(CAMPAIGN_RULE_ID);
                            command.Parameters.Add(CAMPAIGN_URL);
                            command.Parameters.Add(CAMPAIGN_REDIRECT_URL);
                            command.Parameters.Add(CAMPAIGN_CONTAINER_ID);
                            command.Parameters.Add(INSERTED_BY);
                            command.Parameters.Add(TS_CNT);
                            command.Parameters.Add(INSERTED_DATE);
                            CAMPAIGN_NAME.Value = _campaign.CAMPAIGN_NAME;
                            CAMPAIGN_DESCRIPTION.Value = Cryptographys.Encrypt(_campaign.CAMPAIGN_DESCRIPTION);
                            CAMPAIGN_START_DATE.Value = _campaign.CAMPAIGN_START_DATE;
                            CAMPAIGN_END_DATE.Value = _campaign.CAMPAIGN_END_DATE;
                            CAMPAIGN_STATUS.Value = _campaign.CAMPAIGN_STATUS;
                            CAMPAIGN_DESIGN_ID.Value = _campaign.CAMPAIGN_DESIGN_ID;
                            CAMPAIGN_CONTENT_ID.Value = _campaign.CAMPAIGN_CONTENT_ID;
                            CAMPAIGN_POPUP_STATUS.Value = _campaign.CAMPAIGN_POPUP_STATUS;
                            CAMPAIGN_POPUP_ID.Value = _campaign.CAMPAIGN_POPUP_ID;
                            CAMPAIGN_RULE_ID.Value = _campaign.CAMPAIGN_RULE_ID;
                            CAMPAIGN_URL.Value = Cryptographys.Encrypt(_campaign.CAMPAIGN_URL);
                            CAMPAIGN_REDIRECT_URL.Value = Cryptographys.Encrypt(_campaign.CAMPAIGN_REDIRECT_URL);

                            CAMPAIGN_CONTAINER_ID.Value = _campaign.CAMPAIGN_CONTAINER_ID;
                            INSERTED_BY.Value = _campaign.INSERTED_BY;
                            INSERTED_DATE.Value = _campaign.INSERTED_DATE;
                            TS_CNT.Value = _campaign.TS_CNT;
                            command.ExecuteNonQuery();
                        }
                    }
                    con.Close();
                    Msg = "Inserted";
                    return Msg;
                }
            }
            catch (Exception ex)
            {
                Utilities objUtilities = new Utilities();
                objUtilities.LogError(ex);
                Msg = "Something went wrong";
                return null;
            }
        }

        public List<pcms_Content> getContents()
        {
            try
            {
                List<pcms_Content> _Content = new List<pcms_Content>();
                using (SqlConnection con = new SqlConnection(_connectionString))
                {
                    con.Open();
                    SqlCommand command = new SqlCommand(null, con);
                    command.CommandText = "select CONTENT_ID,CONTENT_NAME,CONTENT_DESCRIPTION from pcms_content where CONTENT_ISDELETED=0 order by INSERTED_DATE desc  ";
                    command.Prepare();
                    SqlDataReader dr = command.ExecuteReader();
                    string str = "";
                    while (dr.Read())
                    {
                        _Content.Add(new pcms_Content
                        {
                            CONTENT_ID = Convert.ToInt16(dr[0].ToString()),
                            CONTENT_NAME = Cryptographys.Decrypt(dr[1].ToString()),
                            CONTENT_DESCRIPTION = Cryptographys.Decrypt(dr[2].ToString())
                        });
                    }
                    con.Close();
                    return _Content;
                }
            }
            catch (Exception ex)
            {
                Utilities objUtilities = new Utilities();
                objUtilities.LogError(ex);
                return null;
            }
        }

        public string AddContent(pcms_Content _Content)
        {
            string Msg = "";
            try
            {
                using (SqlConnection con = new SqlConnection(_connectionString))
                {
                    con.Open();
                    SqlCommand com = new SqlCommand(null, con);
                    com.CommandText = "select count(*) as count from pcms_content where CONTENT_NAME=@CONTENT_NAME";
                    SqlParameter contentName = new SqlParameter("@CONTENT_NAME", SqlDbType.VarChar, 50);
                    contentName.Value = _Content.CONTENT_NAME;
                    com.Parameters.Add(contentName);
                    com.Prepare();
                    SqlDataReader dr = com.ExecuteReader();
                    string str = "";
                    while (dr.Read())
                    {
                        if (Convert.ToInt16(dr[0]) > 0)
                        {
                            Msg = "Duplicate";
                        }
                        else
                        {
                            SqlCommand command = new SqlCommand(null, con);
                            command.CommandText = "insert into pcms_content(CONTENT_NAME,CONTENT_DESCRIPTION,CONTENT_HTML,INSERTED_BY,INSERTED_DATE,CONTENT_ISDELETED,TS_CNT) values(@CONTENT_NAME,@CONTENT_DESCRIPTION,@CONTENT_HTML,@INSERTED_BY,@INSERTED_DATE,@CONTENT_ISDELETED,@TS_CNT)";
                            SqlParameter CONTENT_NAME = new SqlParameter("@CONTENT_NAME", SqlDbType.VarChar, 50);
                            SqlParameter CONTENT_DESCRIPTION = new SqlParameter("@CONTENT_DESCRIPTION", SqlDbType.NVarChar, 1000);
                            SqlParameter CONTENT_HTML = new SqlParameter("@CONTENT_HTML", SqlDbType.NVarChar, 4000);
                            SqlParameter INSERTED_BY = new SqlParameter("@INSERTED_BY", SqlDbType.VarChar, 50);
                            SqlParameter INSERTED_DATE = new SqlParameter("@INSERTED_DATE", SqlDbType.DateTime, 16);
                            SqlParameter CONTENT_ISDELETED = new SqlParameter("@CONTENT_ISDELETED", SqlDbType.Bit, 16);
                            SqlParameter TS_CNT = new SqlParameter("@TS_CNT", SqlDbType.Int, 16);
                            CONTENT_NAME.Value = Cryptographys.Encrypt(_Content.CONTENT_NAME);
                            CONTENT_DESCRIPTION.Value = Cryptographys.Encrypt(_Content.CONTENT_DESCRIPTION);
                            CONTENT_HTML.Value = Cryptographys.Encrypt(_Content.CONTENT_HTML);
                            INSERTED_BY.Value = _Content.INSERTED_BY;
                            INSERTED_DATE.Value = _Content.INSERTED_DATE;
                            CONTENT_ISDELETED.Value = _Content.CONTENT_ISDELETED;
                            TS_CNT.Value = _Content.TS_CNT;
                            command.Parameters.Add(CONTENT_NAME);
                            command.Parameters.Add(CONTENT_DESCRIPTION);
                            command.Parameters.Add(CONTENT_HTML);
                            command.Parameters.Add(INSERTED_BY);
                            command.Parameters.Add(INSERTED_DATE);
                            command.Parameters.Add(CONTENT_ISDELETED);
                            command.Parameters.Add(TS_CNT);
                            command.ExecuteNonQuery();
                        }
                    }
                    con.Close();
                    Msg = "Inserted";
                    return Msg;
                }
            }
            catch (Exception ex)
            {
                Utilities objUtilities = new Utilities();
                objUtilities.LogError(ex);
                Msg = "Something went wrong";
                return null;
            }
        }

        public string DeleteContent(int query)
        {

            string Msg = "";
            try
            {
                using (SqlConnection con = new SqlConnection(_connectionString))
                {
                    con.Open();
                    SqlCommand com = new SqlCommand(null, con);
                    com.CommandText = "update pcms_content set CONTENT_ISDELETED=1 where CONTENT_ID=@CONTENT_ID";
                    SqlParameter contentID = new SqlParameter("@CONTENT_ID", SqlDbType.Int, 16);
                    contentID.Value = query;
                    com.Parameters.Add(contentID);
                    com.Prepare();
                    com.ExecuteNonQuery();
                    con.Close();
                    Msg = "Deleted";
                    return Msg;
                }
            }
            catch (Exception ex)
            {
                Utilities objUtilities = new Utilities();
                objUtilities.LogError(ex);
                Msg = "Something went wrong";
                return null;
            }

        }

        public pcms_Content EditContent(int query)
        {
            pcms_Content _content = new pcms_Content();
            try
            {
                using (SqlConnection con = new SqlConnection(_connectionString))
                {
                    con.Open();
                    SqlCommand com = new SqlCommand(null, con);
                    com.CommandText = "select CONTENT_ID,CONTENT_NAME,CONTENT_DESCRIPTION,CONTENT_HTML from pcms_content where CONTENT_ID=@CONTENT_ID";
                    SqlParameter contentID = new SqlParameter("@CONTENT_ID", SqlDbType.Int, 16);
                    contentID.Value = query;
                    com.Parameters.Add(contentID);
                    com.Prepare();
                    SqlDataReader dr = com.ExecuteReader();
                    string str = "";
                    while (dr.Read())
                    {
                        _content.CONTENT_ID = Convert.ToInt16(dr[0].ToString());
                        _content.CONTENT_NAME = Cryptographys.Decrypt(dr[1].ToString());
                        _content.CONTENT_DESCRIPTION = Cryptographys.Decrypt(dr[2].ToString());
                        _content.CONTENT_HTML = Cryptographys.Decrypt(dr[3].ToString());
                    }
                    con.Close();
                    return _content;
                }
            }
            catch (Exception ex)
            {
                Utilities objUtilities = new Utilities();
                objUtilities.LogError(ex);
                return null;
            }
        }

        public string UpdateContent(pcms_Content _content)
        {

            string Msg = "";
            try
            {
                using (SqlConnection con = new SqlConnection(_connectionString))
                {
                    con.Open();
                    SqlCommand com = new SqlCommand(null, con);
                    com.CommandText = "update pcms_content set CONTENT_DESCRIPTION=@CONTENT_DESCRIPTION,CONTENT_HTML=@CONTENT_HTML,UPDATED_BY=@UPDATED_BY,UPDATED_DATE=@UPDATED_DATE,TS_CNT=@TS_CNT WHERE CONTENT_ID=@CONTENT_ID";

                    SqlParameter CONTENT_DESCRIPTION = new SqlParameter("@CONTENT_DESCRIPTION", SqlDbType.NVarChar, 1000);
                    SqlParameter CONTENT_HTML = new SqlParameter("@CONTENT_HTML", SqlDbType.NVarChar, -1);
                    SqlParameter UPDATED_BY = new SqlParameter("@UPDATED_BY", SqlDbType.NVarChar, 16);
                    SqlParameter UPDATED_DATE = new SqlParameter("@UPDATED_DATE", SqlDbType.DateTime, -1);
                    SqlParameter TS_CNT = new SqlParameter("@TS_CNT", SqlDbType.Int, 16);
                    SqlParameter CONTENT_ID = new SqlParameter("@CONTENT_ID", SqlDbType.Int, 16);
                    CONTENT_DESCRIPTION.Value = Cryptographys.Encrypt(_content.CONTENT_DESCRIPTION);
                    UPDATED_BY.Value = _content.UPDATED_BY;
                    CONTENT_ID.Value = _content.CONTENT_ID;
                    CONTENT_HTML.Value = Cryptographys.Encrypt(_content.CONTENT_HTML);
                    UPDATED_DATE.Value = _content.UPDATED_DATE;
                    TS_CNT.Value = _content.TS_CNT;
                    com.Parameters.Add(CONTENT_ID);
                    com.Parameters.Add(CONTENT_DESCRIPTION);
                    com.Parameters.Add(CONTENT_HTML);
                    com.Parameters.Add(UPDATED_BY);
                    com.Parameters.Add(UPDATED_DATE);
                    com.Parameters.Add(TS_CNT);
                    com.Prepare();
                    com.ExecuteNonQuery();
                    con.Close();
                    Msg = "Updated";
                    return Msg;
                }
            }
            catch (Exception ex)
            {
                Utilities objUtilities = new Utilities();
                objUtilities.LogError(ex);
                Msg = "Something went wrong";
                return null;
            }
        }

        public string AddWebsite(pcms_List list)
        {
            string Msg = "";
            try
            {
                using (SqlConnection con = new SqlConnection(_connectionString))
                {
                    con.Open();
                    SqlCommand com = new SqlCommand(null, con);
                    com.CommandText = "select count(*) as count from pcms_website where WEBSITE_URL=@WEBSITE_URL";
                    SqlParameter webUrl = new SqlParameter("@WEBSITE_URL", SqlDbType.VarChar, 50);
                    webUrl.Value = list.url[0].WEBSITE_URL;
                    com.Parameters.Add(webUrl);
                    com.Prepare();
                    SqlDataReader dr = com.ExecuteReader();
                    string str = "";
                    while (dr.Read())
                    {
                        if (Convert.ToInt16(dr[0]) > 0)
                        {
                            Msg = "Duplicate";
                        }
                        else
                        {
                            SqlCommand command = new SqlCommand(null, con);
                            command.CommandText = "insert into pcms_website(WEBSITE_URL,WEBSITE_SITEMAP_URL,SDK_VERIFIED,INSERTED_BY,INSERTED_DATE,TS_CNT) values(@WEBSITE_URL,@WEBSITE_SITEMAP_URL,@SDK_VERIFIED,@INSERTED_BY,@INSERTED_DATE,@TS_CNT)" +
                                "insert into pcms_rules(RULE_APPLIED_URL,INSERTED_BY,INSERTED_DATE,WEBSITE_URL,TS_CNT) values(@ENWEBSITE_SITEMAP_URL,@INSERTED_BY,@INSERTED_DATE,@ENWEBSITE_URL,@TS_CNT)";
                            SqlParameter WEBSITE_URL = new SqlParameter("@WEBSITE_URL", SqlDbType.VarChar, -1);
                            SqlParameter WEBSITE_SITEMAP_URL = new SqlParameter("@WEBSITE_SITEMAP_URL", SqlDbType.NVarChar, -1);
                            SqlParameter ENWEBSITE_URL = new SqlParameter("@ENWEBSITE_URL", SqlDbType.VarChar, -1);
                            SqlParameter ENWEBSITE_SITEMAP_URL = new SqlParameter("@ENWEBSITE_SITEMAP_URL", SqlDbType.NVarChar, -1);
                            SqlParameter SDK_VERIFIED = new SqlParameter("@SDK_VERIFIED", SqlDbType.Bit, 16);
                            SqlParameter INSERTED_BY = new SqlParameter("@INSERTED_BY", SqlDbType.NVarChar, 50);
                            SqlParameter INSERTED_DATE = new SqlParameter("@INSERTED_DATE", SqlDbType.DateTime, -1);
                            SqlParameter TS_CNT = new SqlParameter("@TS_CNT", SqlDbType.Int, 16);
                            command.Parameters.Add(WEBSITE_URL);
                            command.Parameters.Add(WEBSITE_SITEMAP_URL);
                            command.Parameters.Add(ENWEBSITE_URL);
                            command.Parameters.Add(ENWEBSITE_SITEMAP_URL);
                            command.Parameters.Add(SDK_VERIFIED);
                            command.Parameters.Add(TS_CNT);
                            command.Parameters.Add(INSERTED_BY);
                            command.Parameters.Add(INSERTED_DATE);
                            ENWEBSITE_URL.Value = Cryptographys.Encrypt(list.url[0].WEBSITE_URL);
                            string webmap = list.url[0].WEBSITE_SITEMAP_URL != null ? list.url[0].WEBSITE_SITEMAP_URL : "";
                            ENWEBSITE_SITEMAP_URL.Value = Cryptographys.Encrypt(webmap);
                            WEBSITE_SITEMAP_URL.Value = list.url[0].WEBSITE_SITEMAP_URL != null ? list.url[0].WEBSITE_SITEMAP_URL : "";
                            WEBSITE_URL.Value = list.url[0].WEBSITE_URL;
                            SDK_VERIFIED.Value = Convert.ToBoolean(list.url[0].SDK_VERIFIED);
                            INSERTED_BY.Value = list.url[0].INSERTED_BY;
                            INSERTED_DATE.Value = list.url[0].INSERTED_DATE;
                            TS_CNT.Value = list.url[0].TS_CNT;
                            command.ExecuteNonQuery();
                            Msg = "Inserted";
                        }
                    }
                    con.Close();
                    return Msg;
                }
            }
            catch (Exception ex)
            {
                Utilities objUtilities = new Utilities();
                objUtilities.LogError(ex);
                Msg = "Something went wrong";
                return null;
            }
        }

        public string UpdateUrlList(string weburl, string insertby, DateTime insertdate, int tscnt, string url)
        {
            string Msg = "";
            try
            {
                using (SqlConnection con = new SqlConnection(_connectionString))
                {
                    con.Open();
                    SqlCommand command = new SqlCommand(null, con);
                    command.CommandText = "insert into pcms_rules(RULE_APPLIED_URL,INSERTED_BY,INSERTED_DATE,WEBSITE_URL,TS_CNT) values(@RULE_APPLIED_URL,@INSERTED_BY,@INSERTED_DATE,@WEBSIT_URL,@TS_CNT)";
                    SqlParameter RULE_APPLIED_URL = new SqlParameter("@RULE_APPLIED_URL", SqlDbType.NVarChar, -1);
                    SqlParameter WEBSIT_URL = new SqlParameter("@WEBSIT_URL", SqlDbType.NVarChar, -1);
                    SqlParameter INSERTED_BY = new SqlParameter("@INSERTED_BY", SqlDbType.NVarChar, 50);
                    SqlParameter INSERTED_DATE = new SqlParameter("@INSERTED_DATE", SqlDbType.DateTime, -1);
                    SqlParameter TS_CNT = new SqlParameter("@TS_CNT", SqlDbType.Int, 16);
                    command.Parameters.Add(RULE_APPLIED_URL);
                    command.Parameters.Add(WEBSIT_URL);
                    command.Parameters.Add(TS_CNT);
                    command.Parameters.Add(INSERTED_BY);
                    command.Parameters.Add(INSERTED_DATE);
                    RULE_APPLIED_URL.Value = Cryptographys.Encrypt(url);
                    WEBSIT_URL.Value = Cryptographys.Encrypt(weburl);
                    INSERTED_BY.Value = insertby;
                    INSERTED_DATE.Value = insertdate;
                    TS_CNT.Value = tscnt;
                    command.ExecuteScalar();
                    con.Close();
                    return Msg = "Inserted";
                }
            }
            catch (Exception ex)
            {
                Utilities objUtilities = new Utilities();
                objUtilities.LogError(ex);
                Msg = "Something went wrong";
                return null;
            }

        }

        public List<pcms_Rules> getUrlList(string url)
        {

            try
            {
                List<pcms_Rules> _Rules = new List<pcms_Rules>();
                using (SqlConnection con = new SqlConnection(_connectionString))
                {
                    con.Open();
                    SqlCommand command = new SqlCommand(null, con);
                    if (string.IsNullOrEmpty(url))
                    {

                        command.CommandText = "select RULE_ID,RULE_NAME,RULE_APPLIED_URL,WEBSITE_URL from pcms_rules where isnull(RULE_ISDELETED,0)=0 order by INSERTED_DATE desc ";
                    }
                    else
                    {
                        command.CommandText = "select RULE_ID,RULE_NAME,RULE_APPLIED_URL,WEBSITE_URL from pcms_rules where isnull(RULE_ISDELETED,0)=0 and WEBSITE_URL=@url order by INSERTED_DATE desc  ";
                        SqlParameter URL = new SqlParameter("@url", SqlDbType.NVarChar, -1);
                        URL.Value = Cryptographys.Encrypt( url);
                        command.Parameters.Add(URL);
                    }
                    command.Prepare();
                    SqlDataReader dr = command.ExecuteReader();
                    string str = "";
                    while (dr.Read())
                    {
                        _Rules.Add(new pcms_Rules
                        {
                            RULE_ID = Convert.ToInt16(dr[0].ToString()),
                            RULE_NAME = dr[1].ToString(),
                            RULE_APPLIED_URL = Cryptographys.Decrypt(dr[2].ToString()),
                            WEBSITE_URL = Cryptographys.Decrypt(dr[3].ToString())
                        });
                    }
                    con.Close();
                    return _Rules;
                }
            }
            catch (Exception ex)
            {
                Utilities objUtilities = new Utilities();
                objUtilities.LogError(ex);
                return null;
            }
        }

        public string DeleteRules(string query)
        {

            string Msg = "";
            try
            {
                using (SqlConnection con = new SqlConnection(_connectionString))
                {
                    con.Open();
                    SqlCommand com = new SqlCommand(null, con);
                    com.CommandText = "update pcms_rules set RULE_ISDELETED=1 where RULE_ID=@RULE_ID";
                    SqlParameter RULE_ID = new SqlParameter("@RULE_ID", SqlDbType.Int, 16);
                    RULE_ID.Value = query;
                    com.Parameters.Add(RULE_ID);
                    com.Prepare();
                    com.ExecuteNonQuery();
                    con.Close();
                    Msg = "Deleted";
                    return Msg;
                }
            }
            catch (Exception ex)
            {
                Utilities objUtilities = new Utilities();
                objUtilities.LogError(ex);
                Msg = "Something went wrong";
                return null;
            }

        }

        public List<pcms_Design> getDesign()
        {
            try
            {
                List<pcms_Design> _Design = new List<pcms_Design>();
                using (SqlConnection con = new SqlConnection(_connectionString))
                {
                    con.Open();
                    SqlCommand command = new SqlCommand(null, con);
                    command.CommandText = "select DESIGN_ID,DESIGN_NAME,DESIGN_DESCRIPTION from pcms_design where DESIGN_ISDELETED=0 order by INSERTED_DATE desc  ";
                    command.Prepare();
                    SqlDataReader dr = command.ExecuteReader();
                    string str = "";
                    while (dr.Read())
                    {
                        _Design.Add(new pcms_Design
                        {
                            DESIGN_ID = Convert.ToInt16(dr[0].ToString()),
                            DESIGN_NAME = Cryptographys.Decrypt(dr[1].ToString()),
                            DESIGN_DESCRIPTION = Cryptographys.Decrypt(dr[2].ToString())
                        });
                    }
                    con.Close();
                    return _Design;
                }
            }
            catch (Exception ex)
            {
                Utilities objUtilities = new Utilities();
                objUtilities.LogError(ex);
                return null;
            }
        }

        public string AddDesign(pcms_Design _Design)
        {
            string Msg = "";
            try
            {
                using (SqlConnection con = new SqlConnection(_connectionString))
                {
                    con.Open();
                    SqlCommand com = new SqlCommand(null, con);
                    com.CommandText = "select count(*) as count from pcms_design where DESIGN_NAME=@DESIGN_NAME";
                    SqlParameter designName = new SqlParameter("@DESIGN_NAME", SqlDbType.VarChar, 50);
                    designName.Value = _Design.DESIGN_NAME;
                    com.Parameters.Add(designName);
                    com.Prepare();
                    SqlDataReader dr = com.ExecuteReader();
                    string str = "";
                    while (dr.Read())
                    {
                        if (Convert.ToInt16(dr[0]) > 0)
                        {
                            Msg = "Duplicate";
                        }
                        else
                        {
                            SqlCommand command = new SqlCommand(null, con);
                            command.CommandText = "insert into pcms_design(DESIGN_NAME,DESIGN_DESCRIPTION,DESIGN_HTML,INSERTED_BY,INSERTED_DATE,DESIGN_ISDELETED,TS_CNT) values(@DESIGN_NAME,@DESIGN_DESCRIPTION,@DESIGN_HTML,@INSERTED_BY,@INSERTED_DATE,@DESIGN_ISDELETED,@TS_CNT)";
                            SqlParameter DESIGN_NAME = new SqlParameter("@DESIGN_NAME", SqlDbType.VarChar, 50);
                            SqlParameter DESIGN_DESCRIPTION = new SqlParameter("@DESIGN_DESCRIPTION", SqlDbType.NVarChar, 1000);
                            SqlParameter DESIGN_HTML = new SqlParameter("@DESIGN_HTML", SqlDbType.NVarChar, 4000);
                            SqlParameter INSERTED_BY = new SqlParameter("@INSERTED_BY", SqlDbType.VarChar, 50);
                            SqlParameter INSERTED_DATE = new SqlParameter("@INSERTED_DATE", SqlDbType.DateTime, 16);
                            SqlParameter DESIGN_ISDELETED = new SqlParameter("@DESIGN_ISDELETED", SqlDbType.Bit, 16);
                            SqlParameter TS_CNT = new SqlParameter("@TS_CNT", SqlDbType.Int, 16);
                            DESIGN_NAME.Value = Cryptographys.Encrypt(_Design.DESIGN_NAME);
                            DESIGN_DESCRIPTION.Value = Cryptographys.Encrypt(_Design.DESIGN_DESCRIPTION);
                            DESIGN_HTML.Value = Cryptographys.Encrypt(_Design.DESIGN_HTML);
                            INSERTED_BY.Value = _Design.INSERTED_BY;
                            INSERTED_DATE.Value = _Design.INSERTED_DATE;
                            DESIGN_ISDELETED.Value = _Design.DESIGN_ISDELETED;
                            TS_CNT.Value = _Design.TS_CNT;
                            command.Parameters.Add(DESIGN_NAME);
                            command.Parameters.Add(DESIGN_DESCRIPTION);
                            command.Parameters.Add(DESIGN_HTML);
                            command.Parameters.Add(INSERTED_BY);
                            command.Parameters.Add(INSERTED_DATE);
                            command.Parameters.Add(DESIGN_ISDELETED);
                            command.Parameters.Add(TS_CNT);
                            command.ExecuteNonQuery();
                        }
                    }
                    con.Close();
                    Msg = "Inserted";
                    return Msg;
                }
            }
            catch (Exception ex)
            {
                Utilities objUtilities = new Utilities();
                objUtilities.LogError(ex);
                Msg = "Something went wrong";
                return null;
            }
        }

        public string DeleteDesign(int query)
        {

            string Msg = "";
            try
            {
                using (SqlConnection con = new SqlConnection(_connectionString))
                {
                    con.Open();
                    SqlCommand com = new SqlCommand(null, con);
                    com.CommandText = "update pcms_design set DESIGN_ISDELETED=1 where DESIGN_ID=@DESIGN_ID";
                    SqlParameter designID = new SqlParameter("@DESIGN_ID", SqlDbType.Int, 16);
                    designID.Value = query;
                    com.Parameters.Add(designID);
                    com.Prepare();
                    com.ExecuteNonQuery();
                    con.Close();
                    Msg = "Deleted";
                    return Msg;
                }
            }
            catch (Exception ex)
            {
                Utilities objUtilities = new Utilities();
                objUtilities.LogError(ex);
                Msg = "Something went wrong";
                return null;
            }

        }

        public pcms_Design EditDesign(int query)
        {
            pcms_Design _Design = new pcms_Design();
            try
            {
                using (SqlConnection con = new SqlConnection(_connectionString))
                {
                    con.Open();
                    SqlCommand com = new SqlCommand(null, con);
                    com.CommandText = "select DESIGN_ID,DESIGN_NAME,DESIGN_DESCRIPTION,DESIGN_HTML from pcms_design where DESIGN_ID=@DESIGN_ID";
                    SqlParameter designID = new SqlParameter("@DESIGN_ID", SqlDbType.Int, 16);
                    designID.Value = query;
                    com.Parameters.Add(designID);
                    com.Prepare();
                    SqlDataReader dr = com.ExecuteReader();
                    // string str = "";
                    while (dr.Read())
                    {
                        _Design.DESIGN_ID = Convert.ToInt16(dr[0].ToString());
                        _Design.DESIGN_NAME = Cryptographys.Decrypt(dr[1].ToString());
                        _Design.DESIGN_DESCRIPTION = Cryptographys.Decrypt(dr[2].ToString());
                        _Design.DESIGN_HTML = Cryptographys.Decrypt(dr[3].ToString());
                    }
                    con.Close();
                    return _Design;
                }
            }
            catch (Exception ex)
            {
                Utilities objUtilities = new Utilities();
                objUtilities.LogError(ex);
                return null;
            }
        }

        public string UpdateDesign(pcms_Design _Design)
        {

            string Msg = "";
            try
            {
                using (SqlConnection con = new SqlConnection(_connectionString))
                {
                    con.Open();
                    SqlCommand com = new SqlCommand(null, con);
                    com.CommandText = "update pcms_design set DESIGN_DESCRIPTION=@DESIGN_DESCRIPTION,DESIGN_HTML=@DESIGN_HTML,UPDATED_BY=@UPDATED_BY,UPDATED_DATE=@UPDATED_DATE,TS_CNT=@TS_CNT WHERE DESIGN_ID=@DESIGN_ID";

                    SqlParameter DESIGN_DESCRIPTION = new SqlParameter("@DESIGN_DESCRIPTION", SqlDbType.NVarChar, 1000);
                    SqlParameter DESIGN_HTML = new SqlParameter("@DESIGN_HTML", SqlDbType.NVarChar, -1);
                    SqlParameter UPDATED_BY = new SqlParameter("@UPDATED_BY", SqlDbType.NVarChar, 16);
                    SqlParameter UPDATED_DATE = new SqlParameter("@UPDATED_DATE", SqlDbType.DateTime, -1);
                    SqlParameter TS_CNT = new SqlParameter("@TS_CNT", SqlDbType.Int, 16);
                    SqlParameter DESIGN_ID = new SqlParameter("@DESIGN_ID", SqlDbType.Int, 16);
                    DESIGN_DESCRIPTION.Value = Cryptographys.Encrypt(_Design.DESIGN_DESCRIPTION);
                    UPDATED_BY.Value = _Design.UPDATED_BY;
                    DESIGN_ID.Value = _Design.DESIGN_ID;
                    DESIGN_HTML.Value = Cryptographys.Encrypt(_Design.DESIGN_HTML);
                    UPDATED_DATE.Value = _Design.UPDATED_DATE;
                    TS_CNT.Value = _Design.TS_CNT;
                    com.Parameters.Add(DESIGN_ID);
                    com.Parameters.Add(DESIGN_DESCRIPTION);
                    com.Parameters.Add(DESIGN_HTML);
                    com.Parameters.Add(UPDATED_BY);
                    com.Parameters.Add(UPDATED_DATE);
                    com.Parameters.Add(TS_CNT);
                    com.Prepare();
                    com.ExecuteNonQuery();
                    con.Close();
                    Msg = "Updated";
                    return Msg;
                }
            }
            catch (Exception ex)
            {
                Utilities objUtilities = new Utilities();
                objUtilities.LogError(ex);
                Msg = "Something went wrong";
                return null;
            }
        }

        public List<pcms_Popup> getpopUp()
        {
            try
            {
                List<pcms_Popup> _Popup = new List<pcms_Popup>();
                using (SqlConnection con = new SqlConnection(_connectionString))
                {
                    con.Open();
                    SqlCommand command = new SqlCommand(null, con);
                    command.CommandText = "select POPUP_ID,POPUP_NAME,POPUP_DESCRIPTION from pcms_popup where POPUP_ISDELETED=0 order by INSERTED_DATE desc  ";
                    command.Prepare();
                    SqlDataReader dr = command.ExecuteReader();
                    string str = "";
                    while (dr.Read())
                    {
                        _Popup.Add(new pcms_Popup
                        {
                            POPUP_ID = Convert.ToInt16(dr[0].ToString()),
                            POPUP_NAME = Cryptographys.Decrypt(dr[1].ToString()),
                            POPUP_DESCRIPTION = Cryptographys.Decrypt(dr[2].ToString())
                        });
                    }
                    con.Close();
                    return _Popup;
                }
            }
            catch (Exception ex)
            {
                Utilities objUtilities = new Utilities();
                objUtilities.LogError(ex);
                return null;
            }
        }

        public string AddpopUp(pcms_Popup _Popup)
        {
            string Msg = "";
            try
            {
                using (SqlConnection con = new SqlConnection(_connectionString))//POPUP
                {
                    con.Open();
                    SqlCommand com = new SqlCommand(null, con);
                    com.CommandText = "select count(*) as count from pcms_popup where POPUP_NAME=@POPUP_NAME";
                    SqlParameter popupName = new SqlParameter("@POPUP_NAME", SqlDbType.VarChar, 50);
                    popupName.Value = _Popup.POPUP_NAME;
                    com.Parameters.Add(popupName);
                    com.Prepare();
                    SqlDataReader dr = com.ExecuteReader();
                    string str = "";
                    while (dr.Read())
                    {
                        if (Convert.ToInt16(dr[0]) > 0)
                        {
                            Msg = "Duplicate";
                        }
                        else
                        {
                            SqlCommand command = new SqlCommand(null, con);
                            command.CommandText = "insert into pcms_popup(POPUP_NAME,POPUP_DESCRIPTION,POPUP_HTML,INSERTED_BY,INSERTED_DATE,POPUP_ISDELETED,TS_CNT) values(@POPUP_NAME,@POPUP_DESCRIPTION,@POPUP_HTML,@INSERTED_BY,@INSERTED_DATE,@POPUP_ISDELETED,@TS_CNT)";
                            SqlParameter POPUP_NAME = new SqlParameter("@POPUP_NAME", SqlDbType.VarChar, 50);
                            SqlParameter POPUP_DESCRIPTION = new SqlParameter("@POPUP_DESCRIPTION", SqlDbType.NVarChar, 1000);
                            SqlParameter POPUP_HTML = new SqlParameter("@POPUP_HTML", SqlDbType.NVarChar, 4000);
                            SqlParameter INSERTED_BY = new SqlParameter("@INSERTED_BY", SqlDbType.VarChar, 50);
                            SqlParameter INSERTED_DATE = new SqlParameter("@INSERTED_DATE", SqlDbType.DateTime, 16);
                            SqlParameter POPUP_ISDELETED = new SqlParameter("@POPUP_ISDELETED", SqlDbType.Bit, 16);
                            SqlParameter TS_CNT = new SqlParameter("@TS_CNT", SqlDbType.Int, 16);
                            POPUP_NAME.Value = Cryptographys.Encrypt(_Popup.POPUP_NAME);
                            POPUP_DESCRIPTION.Value = Cryptographys.Encrypt(_Popup.POPUP_DESCRIPTION);
                            POPUP_HTML.Value = Cryptographys.Encrypt(_Popup.POPUP_HTML);
                            INSERTED_BY.Value = _Popup.INSERTED_BY;
                            INSERTED_DATE.Value = _Popup.INSERTED_DATE;
                            POPUP_ISDELETED.Value = _Popup.POPUP_ISDELETED;
                            TS_CNT.Value = _Popup.TS_CNT;
                            command.Parameters.Add(POPUP_NAME);
                            command.Parameters.Add(POPUP_DESCRIPTION);
                            command.Parameters.Add(POPUP_HTML);
                            command.Parameters.Add(INSERTED_BY);
                            command.Parameters.Add(INSERTED_DATE);
                            command.Parameters.Add(POPUP_ISDELETED);
                            command.Parameters.Add(TS_CNT);
                            command.ExecuteNonQuery();
                        }
                    }
                    con.Close();
                    Msg = "Inserted";
                    return Msg;
                }
            }
            catch (Exception ex)
            {
                Utilities objUtilities = new Utilities();
                objUtilities.LogError(ex);
                Msg = "Something went wrong";
                return null;
            }
        }

        public string DeletepopUp(int query)
        {

            string Msg = "";
            try
            {
                using (SqlConnection con = new SqlConnection(_connectionString))
                {
                    con.Open();
                    SqlCommand com = new SqlCommand(null, con);
                    com.CommandText = "update pcms_popup set POPUP_ISDELETED=1 where POPUP_ID=@POPUP_ID";
                    SqlParameter popupID = new SqlParameter("@POPUP_ID", SqlDbType.Int, 16);
                    popupID.Value = query;
                    com.Parameters.Add(popupID);
                    com.Prepare();
                    com.ExecuteNonQuery();
                    con.Close();
                    Msg = "Deleted";
                    return Msg;
                }
            }
            catch (Exception ex)
            {
                Utilities objUtilities = new Utilities();
                objUtilities.LogError(ex);
                Msg = "Something went wrong";
                return null;
            }

        }

        public pcms_Popup EditpopUp(int query)
        {
            pcms_Popup _Popup = new pcms_Popup();
            try
            {
                using (SqlConnection con = new SqlConnection(_connectionString))
                {
                    con.Open();
                    SqlCommand com = new SqlCommand(null, con);
                    com.CommandText = "select POPUP_ID,POPUP_NAME,POPUP_DESCRIPTION,POPUP_HTML from pcms_popup where POPUP_ID=@POPUP_ID";
                    SqlParameter popupID = new SqlParameter("@POPUP_ID", SqlDbType.Int, 16);
                    popupID.Value = query;
                    com.Parameters.Add(popupID);
                    com.Prepare();
                    SqlDataReader dr = com.ExecuteReader();
                    // string str = "";
                    while (dr.Read())
                    {
                        _Popup.POPUP_ID = Convert.ToInt16(dr[0].ToString());
                        _Popup.POPUP_NAME = Cryptographys.Decrypt(dr[1].ToString());
                        _Popup.POPUP_DESCRIPTION = Cryptographys.Decrypt(dr[2].ToString());
                        _Popup.POPUP_HTML = Cryptographys.Decrypt(dr[3].ToString());
                    }
                    con.Close();
                    return _Popup;
                }
            }
            catch (Exception ex)
            {
                Utilities objUtilities = new Utilities();
                objUtilities.LogError(ex);
                return null;
            }
        }

        public string UpdatepopUp(pcms_Popup _Popup)
        {

            string Msg = "";
            try
            {
                using (SqlConnection con = new SqlConnection(_connectionString))
                {
                    con.Open();
                    SqlCommand com = new SqlCommand(null, con);
                    com.CommandText = "update pcms_popup set POPUP_DESCRIPTION=@POPUP_DESCRIPTION,POPUP_HTML=@POPUP_HTML,UPDATED_BY=@UPDATED_BY,UPDATED_DATE=@UPDATED_DATE,TS_CNT=@TS_CNT WHERE POPUP_ID=@POPUP_ID";

                    SqlParameter POPUP_DESCRIPTION = new SqlParameter("@POPUP_DESCRIPTION", SqlDbType.NVarChar, 1000);
                    SqlParameter POPUP_HTML = new SqlParameter("@POPUP_HTML", SqlDbType.NVarChar, -1);
                    SqlParameter UPDATED_BY = new SqlParameter("@UPDATED_BY", SqlDbType.NVarChar, 16);
                    SqlParameter UPDATED_DATE = new SqlParameter("@UPDATED_DATE", SqlDbType.DateTime, -1);
                    SqlParameter TS_CNT = new SqlParameter("@TS_CNT", SqlDbType.Int, 16);
                    SqlParameter POPUP_ID = new SqlParameter("@POPUP_ID", SqlDbType.Int, 16);
                    POPUP_DESCRIPTION.Value = Cryptographys.Encrypt(_Popup.POPUP_DESCRIPTION);
                    UPDATED_BY.Value = _Popup.UPDATED_BY;
                    POPUP_ID.Value = _Popup.POPUP_ID;
                    POPUP_HTML.Value = Cryptographys.Encrypt(_Popup.POPUP_HTML);
                    UPDATED_DATE.Value = _Popup.UPDATED_DATE;
                    TS_CNT.Value = _Popup.TS_CNT;
                    com.Parameters.Add(POPUP_ID);
                    com.Parameters.Add(POPUP_DESCRIPTION);
                    com.Parameters.Add(POPUP_HTML);
                    com.Parameters.Add(UPDATED_BY);
                    com.Parameters.Add(UPDATED_DATE);
                    com.Parameters.Add(TS_CNT);
                    com.Prepare();
                    com.ExecuteNonQuery();
                    con.Close();
                    Msg = "Updated";
                    return Msg;
                }
            }
            catch (Exception ex)
            {
                Utilities objUtilities = new Utilities();
                objUtilities.LogError(ex);
                Msg = "Something went wrong";
                return null;
            }
        }

        public List<pcms_Rules> getURLBYID(string query)
        {

            try
            {
                List<pcms_Rules> _Rule = new List<pcms_Rules>();
                using (SqlConnection con = new SqlConnection(_connectionString))
                {
                    con.Open();
                    SqlCommand command = new SqlCommand(null, con);
                    command.CommandText = "select RULE_ID,RULE_APPLIED_URL,WEBSITE_URL from pcms_rules where RULE_ID=@RULE_ID";
                    SqlParameter RULE_ID = new SqlParameter("@RULE_ID", SqlDbType.Int, 16);
                    RULE_ID.Value = query;
                    command.Parameters.Add(RULE_ID);
                    command.Prepare();
                    SqlDataReader dr = command.ExecuteReader();
                    while (dr.Read())
                    {
                        _Rule.Add(new pcms_Rules
                        {
                            RULE_ID = dr.IsDBNull(0) ? 0 : Convert.ToInt16(dr[0]),
                            RULE_APPLIED_URL = Cryptographys.Decrypt(dr[1].ToString()),
                            WEBSITE_URL = Cryptographys.Decrypt(dr[2].ToString())
                        });
                    }
                    con.Close();
                    return _Rule;
                }
            }
            catch (Exception ex)
            {
                Utilities objUtilities = new Utilities();
                objUtilities.LogError(ex);
                return null;
            }
        }

        public List<Country> GetCountryList()
        {
            try
            {
                List<Country> _Country = new List<Country>();
                using (SqlConnection con = new SqlConnection(_connectionString))
                {
                    con.Open();
                    SqlCommand command = new SqlCommand(null, con);
                    command.CommandText = "select COUNTRY_ID,COUNTRY_CODE,COUNTRY_NAME from pcms_country_list order by COUNTRY_NAME asc";
                    command.Prepare();
                    SqlDataReader dr = command.ExecuteReader();
                    string str = "";
                    while (dr.Read())
                    {
                        _Country.Add(new Country
                        {
                            COUNTRY_ID = Convert.ToInt16(dr[0]),
                            COUNTRY_NAME = dr[2].ToString(),
                            COUNTRY_CODE = dr[0].ToString()
                        });
                    }
                    con.Close();
                    return _Country;
                }
            }
            catch (Exception ex)
            {
                Utilities objUtilities = new Utilities();
                objUtilities.LogError(ex);
                return null;
            }

        }

        public string updateRules(pcms_Rules Rule)
        {
            string Msg = "";
            try
            {
                using (SqlConnection con = new SqlConnection(_connectionString))
                {
                    con.Open();
                    SqlCommand command = new SqlCommand(null, con);
                    command.CommandText = "select count(*) as count from pcms_Rules where RULE_NAME=@RULE_NAME";
                    SqlParameter ruleName = new SqlParameter("@RULE_NAME", SqlDbType.VarChar, 50);
                    ruleName.Value = Cryptographys.Encrypt(Rule.RULE_NAME);
                    command.Parameters.Add(ruleName);
                    command.Prepare();
                    SqlDataReader dr = command.ExecuteReader();
                    while (dr.Read())
                    {
                        if (Convert.ToInt16(dr[0]) > 0)
                        {
                            Msg = "Duplicate";
                        }
                        else
                        {
                            SqlCommand com = new SqlCommand(null, con);
                            com.CommandText = "insert into pcms_rules(RULE_NAME,RULE_LOCATION,RULE_USER_TYPE,RULE_PARAMETER_KEY_VALUE,RULE_APPLIED_URL,RULE_ISDELETED,INSERTED_BY,INSERTED_DATE,WEBSITE_URL,TS_CNT) values(@RULE_NAME,@RULE_LOCATION,@RULE_USER_TYPE,@RULE_PARAMETER_KEY_VALUE,@RULE_APPLIED_URL,@RULE_ISDELETED,@INSERTED_BY,@INSERTED_DATE,@WEBSITE_URL,@TS_CNT)";
                            SqlParameter RULE_NAME = new SqlParameter("@RULE_NAME", SqlDbType.NVarChar, 50);
                            SqlParameter RULE_LOCATION = new SqlParameter("@RULE_LOCATION", SqlDbType.NVarChar, 200);
                            SqlParameter RULE_USER_TYPE = new SqlParameter("@RULE_USER_TYPE", SqlDbType.NVarChar, 16);
                            SqlParameter RULE_PARAMETER_KEY_VALUE = new SqlParameter("@RULE_PARAMETER_KEY_VALUE", SqlDbType.NVarChar, -1);
                            SqlParameter RULE_APPLIED_URL = new SqlParameter("@RULE_APPLIED_URL", SqlDbType.NVarChar, -1);
                            SqlParameter RULE_ISDELETED = new SqlParameter("@RULE_ISDELETED", SqlDbType.Bit, 16);
                            SqlParameter INSERTED_BY = new SqlParameter("@INSERTED_BY", SqlDbType.NVarChar, 50);
                            SqlParameter INSERTED_DATE = new SqlParameter("@INSERTED_DATE", SqlDbType.DateTime, -1);
                            SqlParameter WEBSITE_URL = new SqlParameter("@WEBSITE_URL", SqlDbType.NVarChar, -1);
                            SqlParameter TS_CNT = new SqlParameter("@TS_CNT", SqlDbType.Int, 16);
                            RULE_NAME.Value = Cryptographys.Encrypt(Rule.RULE_NAME);
                            RULE_LOCATION.Value = Rule.RULE_LOCATION;
                            RULE_USER_TYPE.Value = Rule.RULE_USER_TYPE;
                            RULE_PARAMETER_KEY_VALUE.Value = Rule.RULE_PARAMETER_KEY_VALUE;
                            RULE_APPLIED_URL.Value = Cryptographys.Encrypt(Rule.RULE_APPLIED_URL);
                            RULE_ISDELETED.Value = Rule.RULE_ISDELETED;
                            INSERTED_BY.Value = Rule.INSERTED_BY;
                            INSERTED_DATE.Value = Rule.INSERTED_DATE;
                            WEBSITE_URL.Value = Cryptographys.Encrypt(Rule.WEBSITE_URL);
                            TS_CNT.Value = Rule.TS_CNT;
                            com.Parameters.Add(RULE_NAME);
                            com.Parameters.Add(RULE_LOCATION);
                            com.Parameters.Add(RULE_USER_TYPE);
                            com.Parameters.Add(RULE_PARAMETER_KEY_VALUE);
                            com.Parameters.Add(RULE_APPLIED_URL);
                            com.Parameters.Add(RULE_ISDELETED);
                            com.Parameters.Add(INSERTED_BY);
                            com.Parameters.Add(WEBSITE_URL);
                            com.Parameters.Add(INSERTED_DATE);
                            com.Parameters.Add(TS_CNT);
                            com.Prepare();
                            com.ExecuteNonQuery();

                            Msg = "Updated";

                        }
                    }
                    con.Close();
                }
                return Msg;
            }
            catch (Exception ex)
            {
                Utilities objUtilities = new Utilities();
                objUtilities.LogError(ex);
                Msg = "Something went wrong";
                return null;
            }
        }

        public List<pcms_Campaign> getCampaignByid(string query)
        {

            try
            {
                List<pcms_Campaign> _campaign = new List<pcms_Campaign>();
                using (SqlConnection con = new SqlConnection(_connectionString))
                {
                    con.Open();
                    SqlCommand command = new SqlCommand(null, con);
                    command.CommandText = "select PK_CAMPAIGN,CAMPAIGN_ID,CAMPAIGN_NAME,CAMPAIGN_START_DATE,CAMPAIGN_END_DATE,CAMPAIGN_STATUS,CAMPAIGN_DESIGN_ID,CAMPAIGN_CONTENT_ID,CAMPAIGN_POPUP_STATUS,CAMPAIGN_POPUP_ID,CAMPAIGN_RULE_ID,CAMPAIGN_URL,CAMPAIGN_REDIRECT_URL,CAMPAIGN_CONTAINER_ID,CAMPAIGN_DESCRIPTION  from pcms_campaign where CAMPAIGN_ID=@CAMPAIGN_ID  order by CAMPAIGN_START_DATE desc ";
                    SqlParameter CAMPAIGN_ID = new SqlParameter("@CAMPAIGN_ID", SqlDbType.Int, 16);
                    CAMPAIGN_ID.Value = Convert.ToInt16(query);
                    command.Parameters.Add(CAMPAIGN_ID);
                    command.Prepare();
                    SqlDataReader dr = command.ExecuteReader();
                    string str = "";
                    while (dr.Read())
                    {
                        _campaign.Add(new pcms_Campaign
                        {
                            PK_CAMPAIGN = dr[0].ToString(),
                            CAMPAIGN_ID = dr[1].ToString(),
                            CAMPAIGN_NAME = dr[2].ToString(),
                            CAMPAIGN_START_DATE = Convert.ToDateTime(dr[3]),
                            CAMPAIGN_END_DATE = Convert.ToDateTime(dr[4]),
                            CAMPAIGN_STATUS = Convert.ToString(dr[5]),
                            CAMPAIGN_DESIGN_ID = Convert.ToInt16(dr[6]),
                            CAMPAIGN_CONTENT_ID = Convert.ToInt16(dr[7]),
                            CAMPAIGN_POPUP_STATUS = dr[8].ToString(),
                            CAMPAIGN_POPUP_ID = dr[9].ToString(),
                            CAMPAIGN_RULE_ID = Convert.ToInt16(dr[10].ToString()),
                            CAMPAIGN_URL = Cryptographys.Decrypt(dr[11].ToString()),
                            CAMPAIGN_REDIRECT_URL = Cryptographys.Decrypt(dr[12].ToString()),
                            CAMPAIGN_CONTAINER_ID = dr[13].ToString(),
                            CAMPAIGN_DESCRIPTION = Cryptographys.Decrypt(dr[14].ToString())
                        });
                    }
                    con.Close();
                    return _campaign;
                }
            }
            catch (Exception ex)
            {
                Utilities objUtilities = new Utilities();
                objUtilities.LogError(ex);
                return null;
            }
        }

        public string UpdateCamaign(pcms_Campaign _campaign)
        {
            string Msg = "";
            try
            {
                using (SqlConnection con = new SqlConnection(_connectionString))
                {
                    con.Open();
                    SqlCommand command = new SqlCommand(null, con);
                    command.CommandText = "update pcms_campaign set CAMPAIGN_NAME=@CAMPAIGN_NAME,CAMPAIGN_DESCRIPTION=@CAMPAIGN_DESCRIPTION,CAMPAIGN_START_DATE=@CAMPAIGN_START_DATE,CAMPAIGN_END_DATE=@CAMPAIGN_END_DATE,CAMPAIGN_STATUS=@CAMPAIGN_STATUS,CAMPAIGN_DESIGN_ID=@CAMPAIGN_DESIGN_ID,CAMPAIGN_CONTENT_ID=@CAMPAIGN_CONTENT_ID,CAMPAIGN_POPUP_STATUS=@CAMPAIGN_POPUP_STATUS,CAMPAIGN_POPUP_ID=@CAMPAIGN_POPUP_ID,CAMPAIGN_RULE_ID=@CAMPAIGN_RULE_ID,CAMPAIGN_URL=@CAMPAIGN_URL,CAMPAIGN_REDIRECT_URL=@CAMPAIGN_REDIRECT_URL,CAMPAIGN_CONTAINER_ID=@CAMPAIGN_CONTAINER_ID,UPDATED_BY=@INSERTED_DATE,UPDATED_DATE=@INSERTED_DATE,TS_CNT=1 WHERE CAMPAIGN_ID=@CAMPAIGN_ID ";
                    SqlParameter CAMPAIGN_NAME = new SqlParameter("@CAMPAIGN_NAME", SqlDbType.VarChar, 50);
                    SqlParameter CAMPAIGN_DESCRIPTION = new SqlParameter("@CAMPAIGN_DESCRIPTION", SqlDbType.NVarChar, 1000);
                    SqlParameter CAMPAIGN_START_DATE = new SqlParameter("@CAMPAIGN_START_DATE", SqlDbType.Date, -1);
                    SqlParameter CAMPAIGN_END_DATE = new SqlParameter("@CAMPAIGN_END_DATE", SqlDbType.Date, -1);
                    SqlParameter CAMPAIGN_STATUS = new SqlParameter("@CAMPAIGN_STATUS", SqlDbType.VarChar, 10);
                    SqlParameter CAMPAIGN_DESIGN_ID = new SqlParameter("@CAMPAIGN_DESIGN_ID", SqlDbType.Int, 16);
                    SqlParameter CAMPAIGN_CONTENT_ID = new SqlParameter("@CAMPAIGN_CONTENT_ID", SqlDbType.Int, 16);
                    SqlParameter CAMPAIGN_POPUP_STATUS = new SqlParameter("@CAMPAIGN_POPUP_STATUS", SqlDbType.VarChar, 8);
                    SqlParameter CAMPAIGN_POPUP_ID = new SqlParameter("@CAMPAIGN_POPUP_ID", SqlDbType.Int, 16);
                    SqlParameter CAMPAIGN_RULE_ID = new SqlParameter("@CAMPAIGN_RULE_ID", SqlDbType.Int, 16);
                    SqlParameter CAMPAIGN_URL = new SqlParameter("@CAMPAIGN_URL", SqlDbType.NVarChar, -1);
                    SqlParameter CAMPAIGN_REDIRECT_URL = new SqlParameter("@CAMPAIGN_REDIRECT_URL", SqlDbType.NVarChar, -1);
                    SqlParameter CAMPAIGN_CONTAINER_ID = new SqlParameter("@CAMPAIGN_CONTAINER_ID", SqlDbType.NVarChar, 16);
                    SqlParameter INSERTED_BY = new SqlParameter("@INSERTED_BY", SqlDbType.NVarChar, 16);
                    SqlParameter INSERTED_DATE = new SqlParameter("@INSERTED_DATE", SqlDbType.DateTime, -1);
                    SqlParameter TS_CNT = new SqlParameter("@TS_CNT", SqlDbType.Int, 16);
                    SqlParameter CAMPAIGN_ID = new SqlParameter("@CAMPAIGN_ID", SqlDbType.Int, 16);
                    command.Parameters.Add(CAMPAIGN_ID);
                    command.Parameters.Add(CAMPAIGN_NAME);
                    command.Parameters.Add(CAMPAIGN_DESCRIPTION);
                    command.Parameters.Add(CAMPAIGN_START_DATE);
                    command.Parameters.Add(CAMPAIGN_END_DATE);
                    command.Parameters.Add(CAMPAIGN_STATUS);
                    command.Parameters.Add(CAMPAIGN_DESIGN_ID);
                    command.Parameters.Add(CAMPAIGN_CONTENT_ID);
                    command.Parameters.Add(CAMPAIGN_POPUP_STATUS);
                    command.Parameters.Add(CAMPAIGN_POPUP_ID);
                    command.Parameters.Add(CAMPAIGN_RULE_ID);
                    command.Parameters.Add(CAMPAIGN_URL);
                    command.Parameters.Add(CAMPAIGN_REDIRECT_URL);
                    command.Parameters.Add(CAMPAIGN_CONTAINER_ID);
                    command.Parameters.Add(INSERTED_BY);
                    command.Parameters.Add(TS_CNT);
                    command.Parameters.Add(INSERTED_DATE);
                    CAMPAIGN_NAME.Value = _campaign.CAMPAIGN_NAME;
                    CAMPAIGN_DESCRIPTION.Value = Cryptographys.Encrypt(_campaign.CAMPAIGN_DESCRIPTION);
                    CAMPAIGN_START_DATE.Value = _campaign.CAMPAIGN_START_DATE;
                    CAMPAIGN_END_DATE.Value = _campaign.CAMPAIGN_END_DATE;
                    CAMPAIGN_STATUS.Value = _campaign.CAMPAIGN_STATUS;
                    CAMPAIGN_DESIGN_ID.Value = _campaign.CAMPAIGN_DESIGN_ID;
                    CAMPAIGN_CONTENT_ID.Value = _campaign.CAMPAIGN_CONTENT_ID;
                    CAMPAIGN_POPUP_STATUS.Value = _campaign.CAMPAIGN_POPUP_STATUS;
                    CAMPAIGN_POPUP_ID.Value = _campaign.CAMPAIGN_POPUP_ID;
                    CAMPAIGN_RULE_ID.Value = _campaign.CAMPAIGN_RULE_ID;
                    CAMPAIGN_URL.Value = Cryptographys.Encrypt(_campaign.CAMPAIGN_URL);
                    CAMPAIGN_REDIRECT_URL.Value = Cryptographys.Encrypt(_campaign.CAMPAIGN_REDIRECT_URL);
                    CAMPAIGN_ID.Value = _campaign.CAMPAIGN_ID;
                    CAMPAIGN_CONTAINER_ID.Value = _campaign.CAMPAIGN_CONTAINER_ID;
                    INSERTED_BY.Value = _campaign.INSERTED_BY;
                    INSERTED_DATE.Value = _campaign.INSERTED_DATE;
                    TS_CNT.Value = _campaign.TS_CNT;
                    command.ExecuteNonQuery();
                    con.Close();
                    Msg = "Updated";
                    return Msg;
                }
            }
            catch (Exception ex)
            {
                Utilities objUtilities = new Utilities();
                objUtilities.LogError(ex);
                Msg = "Something went wrong";
                return null;
            }
        }

        public List<pcms_Website> getWebURL()
        {
            try
            {
                List<pcms_Website> resultset = new List<pcms_Website>();
                using (SqlConnection con = new SqlConnection(_connectionString))
                {
                    con.Open();
                    SqlCommand command = new SqlCommand(null, con);
                    command.CommandText = "select WEBSITE_ID,WEBSITE_URL  from pcms_website  order by INSERTED_DATE desc ";
                    command.Prepare();
                    SqlDataReader dr = command.ExecuteReader();
                    string str = "";
                    while (dr.Read())
                    {
                        resultset.Add(new pcms_Website
                        {
                            WEBSITE_ID = Convert.ToInt16(dr[0]),
                            WEBSITE_URL = dr[1].ToString()

                        });
                    }
                    con.Close();
                    return resultset;
                }
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public string SaveURL(string usr, string url, string usrby)
        {
            string Msg = "";
            try
            {
                using (SqlConnection con = new SqlConnection(_connectionString))
                {
                    con.Open();
                    SqlCommand command = new SqlCommand(null, con);
                    command.CommandText = "insert into pcms_rules(RULE_APPLIED_URL,INSERTED_BY,INSERTED_DATE,WEBSITE_URL,TS_CNT) values(@RULE_APPLIED_URL,@INSERTED_BY,@INSERTED_DATE,@WEBSITE_URL,@TS_CNT)";
                    SqlParameter WEBSITE_URL = new SqlParameter("@WEBSITE_URL", SqlDbType.NVarChar, -1);
                    SqlParameter RULE_APPLIED_URL = new SqlParameter("@RULE_APPLIED_URL", SqlDbType.NVarChar, -1);
                    SqlParameter INSERTED_BY = new SqlParameter("@INSERTED_BY", SqlDbType.NVarChar, 16);
                    SqlParameter TS_CNT = new SqlParameter("@TS_CNT", SqlDbType.Int, 16);
                    SqlParameter INSERTED_DATE = new SqlParameter("@INSERTED_DATE", SqlDbType.DateTime, -1);
                    WEBSITE_URL.Value = Cryptographys.Encrypt(usr);
                    INSERTED_BY.Value = usrby;
                    RULE_APPLIED_URL.Value = Cryptographys.Encrypt(url);
                    INSERTED_DATE.Value = DateTime.Now;
                    TS_CNT.Value = 1;
                    command.Parameters.Add(INSERTED_BY);
                    command.Parameters.Add(TS_CNT);
                    command.Parameters.Add(INSERTED_DATE);
                    command.Parameters.Add(WEBSITE_URL);
                    command.Parameters.Add(RULE_APPLIED_URL);
                    command.Prepare();
                    command.ExecuteNonQuery();
                    Msg = "Inserted";
                    con.Close();
                }

                return Msg;
            }
            catch (Exception ex)
            {
                return Msg = ex.Message;
            }
        }
        public List<pcms_Campaign> GetCampaignList(string query)
        {
            try
            {
                List<pcms_Campaign> _campaign = new List<pcms_Campaign>();
                using (SqlConnection con = new SqlConnection(_connectionString))
                {
                    con.Open();
                    SqlCommand command = new SqlCommand(null, con);
                    command.CommandText = "select PK_CAMPAIGN,CAMPAIGN_ID,CAMPAIGN_NAME,CAMPAIGN_START_DATE,CAMPAIGN_END_DATE,CAMPAIGN_STATUS  from pcms_campaign where CAMPAIGN_RULE_ID=@Campaignid order by CAMPAIGN_START_DATE desc ";
                    SqlParameter Campaignid = new SqlParameter("@Campaignid", SqlDbType.Int, 16);
                    Campaignid.Value = query;
                    command.Parameters.Add(Campaignid);
                    command.Prepare();
                    SqlDataReader dr = command.ExecuteReader();
                    string str = "";
                    while (dr.Read())
                    {
                        _campaign.Add(new pcms_Campaign
                        {
                            PK_CAMPAIGN = dr[0].ToString(),
                            CAMPAIGN_ID = dr[1].ToString(),
                            CAMPAIGN_NAME = dr[2].ToString(),
                            CAMPAIGN_START_DATE = Convert.ToDateTime(dr[3]),
                            CAMPAIGN_END_DATE = Convert.ToDateTime(dr[4]),
                            CAMPAIGN_STATUS = Convert.ToString(dr[5]),


                        });
                    }
                    con.Close();
                    return _campaign;
                }
            }
            catch (Exception ex)
            {
                Utilities objUtilities = new Utilities();
                objUtilities.LogError(ex);
                return null;
            }
        }
    }
}
