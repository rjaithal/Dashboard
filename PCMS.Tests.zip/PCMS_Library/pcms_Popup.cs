﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PCMS_Library
{
    public class pcms_Popup
    {
        public string POPUP_PK { get; set; }
        public int POPUP_ID { get; set; }
        public string POPUP_NAME { get; set; }
        public string POPUP_DESCRIPTION { get; set; }
        public string POPUP_HTML { get; set; }
        public string POPUP_FIELDS { get; set; }
        public string INSERTED_BY { get; set; }
        public DateTime INSERTED_DATE { get; set; }
        public string UPDATED_BY { get; set; }
        public DateTime UPDATED_DATE { get; set; }
        public bool POPUP_ISDELETED { get; set; }
        public int TS_CNT { get; set; }
    }
}
