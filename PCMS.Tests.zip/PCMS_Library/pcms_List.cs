﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PCMS_Library
{
    public class pcms_List
    {
        public List<pcms_Website> url { get; set; }
        public List<pcms_Rules> rules { get; set; }
    }
}
