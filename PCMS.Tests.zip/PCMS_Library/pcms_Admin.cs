﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PCMS_Library
{
    public class pcms_Admin
    {
        public string ADMIN_PK { get; set; }
        public int ADMIN_ID { get; set; }
        public string ADMIN_USERNAME { get; set; }
        public string ADMIN_PASSWORD { get; set; }
        public string INSERTED_BY { get; set; }
        public DateTime INSERTED_DATE { get; set; }
        public string UPDATED_BY { get; set; }
        public DateTime  UPDATED_DATE { get; set; }
        public int TS_CNT { get; set; }
    }
}
