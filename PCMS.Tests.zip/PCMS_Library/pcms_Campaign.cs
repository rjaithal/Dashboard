﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PCMS_Library
{
    public class pcms_Campaign
    {
        public string PK_CAMPAIGN { get; set; }
        public string CAMPAIGN_ID { get; set; }
        public string CAMPAIGN_NAME { get; set; }
        public string CAMPAIGN_DESCRIPTION { get; set; }
        public DateTime CAMPAIGN_START_DATE { get; set; }
        public DateTime CAMPAIGN_END_DATE { get; set; }
        public string CAMPAIGN_STATUS { get; set; }
        public int CAMPAIGN_DESIGN_ID { get; set; }
        public int CAMPAIGN_CONTENT_ID { get; set; }
        public string CAMPAIGN_POPUP_STATUS { get; set; }
        public int CAMPAIGN_RULE_ID { get; set; }
        public string CAMPAIGN_URL { get; set; }
        public string CAMPAIGN_REDIRECT_URL { get; set; }
        public string INSERTED_BY { get; set; }
        public string CAMPAIGN_FIELDS { get; set; }
        public DateTime INSERTED_DATE { get; set; }
        public string UPDATED_BY { get; set; }
        public string CAMPAIGN_CONTAINER_ID { get; set; }
        public DateTime UPDATED_DATE { get; set; }
        public int TS_CNT { get; set; }
        public string CAMPAIGN_POPUP_ID { get; set; }
    }
}
