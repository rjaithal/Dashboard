﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PCMS_Library
{
    public class pcms_Rules
    {
        public string RULE_PK { get; set; }
        public int RULE_ID { get; set; }
        public string RULE_NAME { get; set; }
        public string RULE_DESCRIPTION { get; set; }
        public string RULE_LOCATION { get; set; }
        public string RULE_USER_TYPE { get; set; }
        public string RULE_PARAMETER_KEY_VALUE { get; set; }
        public string RULE_APPLIED_URL { get; set; }
        public bool RULE_ISDELETED { get; set; }
        public string INSERTED_BY { get; set; }
        public DateTime INSERTED_DATE { get; set; }
        public string UPDATED_BY { get; set; }
        public DateTime UPDATED_DATE { get; set; }
        public string RULE_FIELDS { get; set; }
        public int TS_CNT { get; set; }
        public string WEBSITE_URL { get; set; }
    }
}
