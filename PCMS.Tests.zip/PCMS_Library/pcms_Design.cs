﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PCMS_Library
{
    public class pcms_Design
    {
        public string DESIGN_PK { get; set; }
        public int DESIGN_ID { get; set; }
        public string DESIGN_NAME { get; set; }
        public string DESIGN_DESCRIPTION { get; set; }
        public string DESIGN_HTML { get; set; }
        public string DESIGN_FIELDS { get; set; }
        public string INSERTED_BY { get; set; }
        public DateTime INSERTED_DATE { get; set; }
        public string UPDATED_BY { get; set; }
        public DateTime UPDATED_DATE { get; set; }
        public bool DESIGN_ISDELETED { get; set; }
        public int TS_CNT { get; set; }
    }
}
